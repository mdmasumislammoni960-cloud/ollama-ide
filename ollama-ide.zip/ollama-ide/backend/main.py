import asyncio
import json
from pathlib import Path
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from app.routers import chat, files, settings
from app.core import config

app = FastAPI(title="Ollama IDE API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(chat.router, prefix="/api")
app.include_router(files.router, prefix="/api")
app.include_router(settings.router, prefix="/api")


@app.get("/api/health")
async def health():
    return {"status": "ok"}


@app.get("/api/health/ollama")
async def health_ollama():
    from app.providers import get_provider
    provider = get_provider("ollama")
    ok = await provider.health_check()
    if ok:
        models = await provider.list_models()
        return {"status": "ok", "models": models}
    return {"status": "error", "detail": "Cannot reach Ollama at " + config.OLLAMA_BASE_URL}


@app.websocket("/ws/terminal")
async def terminal_ws(websocket: WebSocket):
    """WebSocket endpoint — streams subprocess output back to the client."""
    await websocket.accept()
    try:
        while True:
            data = await websocket.receive_text()
            msg = json.loads(data)
            cmd_type = msg.get("type")

            if cmd_type == "run":
                file_path = msg.get("path", "")
                from app.core.security import safe_path
                from app.services.executor import run_file, LANGUAGE_RUNNERS
                try:
                    full = safe_path(file_path)
                    suffix = full.suffix.lower()
                    runner = LANGUAGE_RUNNERS.get(suffix)
                    if not runner:
                        await websocket.send_text(json.dumps({
                            "type": "output",
                            "data": f"Error: unsupported file type '{suffix}'\r\n"
                        }))
                        await websocket.send_text(json.dumps({"type": "done", "code": 1}))
                        continue

                    cmd = runner + [str(full)]
                    proc = await asyncio.create_subprocess_exec(
                        *cmd,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.STDOUT,
                        cwd=full.parent,
                    )

                    async def stream_output():
                        while True:
                            chunk = await proc.stdout.read(256)
                            if not chunk:
                                break
                            await websocket.send_text(json.dumps({
                                "type": "output",
                                "data": chunk.decode(errors="replace")
                            }))

                    try:
                        await asyncio.wait_for(stream_output(), timeout=config.MAX_EXEC_TIMEOUT)
                        await proc.wait()
                        await websocket.send_text(json.dumps({"type": "done", "code": proc.returncode}))
                    except asyncio.TimeoutError:
                        proc.kill()
                        await websocket.send_text(json.dumps({
                            "type": "output",
                            "data": f"\r\nError: timed out after {config.MAX_EXEC_TIMEOUT}s\r\n"
                        }))
                        await websocket.send_text(json.dumps({"type": "done", "code": -1}))

                except Exception as e:
                    await websocket.send_text(json.dumps({"type": "error", "data": str(e)}))

            elif cmd_type == "ping":
                await websocket.send_text(json.dumps({"type": "pong"}))

    except WebSocketDisconnect:
        pass
