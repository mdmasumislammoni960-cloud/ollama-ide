import os
from fastapi import APIRouter
from app.models.settings import ApiKeyUpdate, OllamaUrlUpdate, WorkspaceUpdate
from app.providers import all_providers
from app.core import config

router = APIRouter(prefix="/settings", tags=["settings"])

# In-memory overrides (survive process lifetime; for persistence write back to .env)
_key_overrides: dict[str, str] = {}


@router.get("/providers")
async def get_providers():
    """Return boolean active status per provider. NEVER return key values."""
    providers = all_providers()
    result = {}
    for name, provider in providers.items():
        active = await provider.health_check()
        result[name] = active
    return result


@router.post("/api-key")
async def set_api_key(req: ApiKeyUpdate):
    """Accept an API key and store it in the process env (not persisted to disk in this demo)."""
    env_map = {
        "anthropic": "ANTHROPIC_API_KEY",
        "openai": "OPENAI_API_KEY",
        "google": "GOOGLE_API_KEY",
        "groq": "GROQ_API_KEY",
    }
    env_var = env_map.get(req.provider.lower())
    if not env_var:
        from fastapi import HTTPException
        raise HTTPException(400, f"Unknown provider: {req.provider}")

    # Update running process env (keys never logged or returned)
    os.environ[env_var] = req.api_key
    setattr(config, env_var, req.api_key)

    # Re-init providers so they pick up new key
    from app.providers import _REGISTRY
    from app.providers.anthropic import AnthropicProvider
    from app.providers.openai import OpenAIProvider
    from app.providers.google import GoogleProvider
    from app.providers.groq import GroqProvider
    reinit_map = {
        "anthropic": AnthropicProvider,
        "openai": OpenAIProvider,
        "google": GoogleProvider,
        "groq": GroqProvider,
    }
    if req.provider.lower() in reinit_map:
        _REGISTRY[req.provider.lower()] = reinit_map[req.provider.lower()]()

    return {"provider": req.provider, "active": True}


@router.post("/ollama-url")
async def set_ollama_url(req: OllamaUrlUpdate):
    os.environ["OLLAMA_BASE_URL"] = req.url
    config.OLLAMA_BASE_URL = req.url
    from app.providers import _REGISTRY
    from app.providers.ollama import OllamaProvider
    _REGISTRY["ollama"] = OllamaProvider()
    return {"url": req.url, "ok": True}


@router.get("/workspace")
async def get_workspace():
    return {"path": config.WORKSPACE_ROOT}


@router.post("/workspace")
async def set_workspace(req: WorkspaceUpdate):
    import pathlib
    p = pathlib.Path(req.path)
    p.mkdir(parents=True, exist_ok=True)
    config.WORKSPACE_ROOT = str(p.resolve())
    return {"path": config.WORKSPACE_ROOT, "ok": True}
