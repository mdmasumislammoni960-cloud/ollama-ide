import json
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from app.models.chat import ChatRequest
from app.providers import get_provider

router = APIRouter(prefix="/chat", tags=["chat"])


@router.post("/stream")
async def stream_chat(req: ChatRequest):
    provider = get_provider(req.provider)
    messages = [{"role": m.role, "content": m.content} for m in req.messages]

    async def generate():
        try:
            async for token in provider.stream_chat(
                messages=messages,
                model=req.model,
                system=req.system,
                temperature=req.temperature,
                top_p=req.top_p,
                max_tokens=req.max_tokens,
            ):
                # Escape token as JSON string to handle newlines/special chars
                yield f"data: {json.dumps(token)}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"
        finally:
            yield "data: [DONE]\n\n"

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/models/{provider_name}")
async def list_models(provider_name: str):
    provider = get_provider(provider_name)
    models = await provider.list_models()
    return {"provider": provider_name, "models": models}
