import os
from pathlib import Path
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from app.core.security import safe_path
from app.core import config
from app.services import executor, git_service

router = APIRouter(prefix="/files", tags=["files"])


class WriteRequest(BaseModel):
    path: str
    content: str


class RunRequest(BaseModel):
    path: str


def _build_tree(directory: Path, root: Path) -> dict:
    rel = str(directory.relative_to(root))
    node = {
        "name": directory.name,
        "path": rel,
        "type": "directory",
        "children": [],
    }
    try:
        entries = sorted(directory.iterdir(), key=lambda e: (e.is_file(), e.name.lower()))
        for entry in entries:
            if entry.name.startswith(".") and entry.name not in (".env.example",):
                continue
            if entry.is_dir():
                node["children"].append(_build_tree(entry, root))
            else:
                node["children"].append({
                    "name": entry.name,
                    "path": str(entry.relative_to(root)),
                    "type": "file",
                })
    except PermissionError:
        pass
    return node


@router.get("/tree")
async def get_tree():
    root = Path(config.WORKSPACE_ROOT)
    root.mkdir(parents=True, exist_ok=True)
    tree = _build_tree(root, root)
    branch = git_service.get_branch()
    return {"tree": tree, "branch": branch}


@router.get("/read")
async def read_file(path: str = Query(...)):
    full = safe_path(path)
    if not full.exists():
        raise HTTPException(404, "File not found")
    if not full.is_file():
        raise HTTPException(400, "Path is not a file")
    try:
        content = full.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        raise HTTPException(500, str(e))
    return {"path": path, "content": content}


@router.post("/write")
async def write_file(req: WriteRequest):
    full = safe_path(req.path)
    full.parent.mkdir(parents=True, exist_ok=True)
    try:
        full.write_text(req.content, encoding="utf-8")
    except Exception as e:
        raise HTTPException(500, str(e))
    return {"path": req.path, "ok": True}


@router.post("/run")
async def run_file(req: RunRequest):
    full = safe_path(req.path)
    if not full.exists():
        raise HTTPException(404, "File not found")
    output = await executor.run_file(full)
    return {"path": req.path, "output": output}


@router.get("/git-status")
async def git_status():
    status = git_service.get_file_status()
    branch = git_service.get_branch()
    return {"branch": branch, "status": status}


@router.delete("/delete")
async def delete_file(path: str = Query(...)):
    full = safe_path(path)
    if not full.exists():
        raise HTTPException(404, "File not found")
    if full.is_dir():
        import shutil
        shutil.rmtree(full)
    else:
        full.unlink()
    return {"path": path, "deleted": True}


@router.post("/mkdir")
async def make_dir(req: WriteRequest):
    full = safe_path(req.path)
    full.mkdir(parents=True, exist_ok=True)
    return {"path": req.path, "ok": True}
