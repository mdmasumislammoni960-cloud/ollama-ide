from typing import AsyncIterator
from app.providers.base import BaseProvider
from app.core import config


class AnthropicProvider(BaseProvider):
    def __init__(self):
        self.api_key = config.ANTHROPIC_API_KEY

    def _get_client(self):
        import anthropic
        return anthropic.AsyncAnthropic(api_key=self.api_key)

    async def stream_chat(
        self,
        messages: list[dict],
        model: str,
        system: str | None,
        temperature: float,
        top_p: float,
        max_tokens: int,
    ) -> AsyncIterator[str]:
        client = self._get_client()
        kwargs = dict(
            model=model,
            max_tokens=max_tokens,
            messages=messages,
            temperature=temperature,
            top_p=top_p,
        )
        if system:
            kwargs["system"] = system

        async with client.messages.stream(**kwargs) as stream:
            async for text in stream.text_stream:
                yield text

    async def list_models(self) -> list[str]:
        return [
            "claude-opus-4-5",
            "claude-sonnet-4-5",
            "claude-haiku-4-5",
        ]

    async def health_check(self) -> bool:
        return bool(self.api_key)
