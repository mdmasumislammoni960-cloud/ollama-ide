from app.providers.base import BaseProvider
from app.providers.ollama import OllamaProvider
from app.providers.anthropic import AnthropicProvider
from app.providers.openai import OpenAIProvider
from app.providers.google import GoogleProvider
from app.providers.groq import GroqProvider

_REGISTRY: dict[str, BaseProvider] = {
    "ollama": OllamaProvider(),
    "anthropic": AnthropicProvider(),
    "openai": OpenAIProvider(),
    "google": GoogleProvider(),
    "groq": GroqProvider(),
}


def get_provider(name: str) -> BaseProvider:
    provider = _REGISTRY.get(name.lower())
    if not provider:
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail=f"Unknown provider: {name}")
    return provider


def all_providers() -> dict[str, BaseProvider]:
    return _REGISTRY
