from typing import AsyncIterator
import asyncio
from app.providers.base import BaseProvider
from app.core import config


class GoogleProvider(BaseProvider):
    def __init__(self):
        self.api_key = config.GOOGLE_API_KEY

    async def stream_chat(
        self,
        messages: list[dict],
        model: str,
        system: str | None,
        temperature: float,
        top_p: float,
        max_tokens: int,
    ) -> AsyncIterator[str]:
        import google.generativeai as genai
        genai.configure(api_key=self.api_key)

        generation_config = {
            "temperature": temperature,
            "top_p": top_p,
            "max_output_tokens": max_tokens,
        }
        system_instruction = system or None
        gemini_model = genai.GenerativeModel(
            model_name=model,
            generation_config=generation_config,
            system_instruction=system_instruction,
        )

        # Convert messages to Gemini format
        history = []
        last_user_msg = ""
        for msg in messages:
            role = "user" if msg["role"] == "user" else "model"
            if msg == messages[-1] and role == "user":
                last_user_msg = msg["content"]
            else:
                history.append({"role": role, "parts": [msg["content"]]})

        chat = gemini_model.start_chat(history=history)

        # Run blocking stream in thread pool
        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None,
            lambda: chat.send_message(last_user_msg, stream=True)
        )
        for chunk in response:
            if chunk.text:
                yield chunk.text

    async def list_models(self) -> list[str]:
        return ["gemini-1.5-pro", "gemini-1.5-flash", "gemini-2.0-flash"]

    async def health_check(self) -> bool:
        return bool(self.api_key)
