from typing import AsyncIterator
from app.providers.base import BaseProvider
from app.core import config


class OpenAIProvider(BaseProvider):
    def __init__(self):
        self.api_key = config.OPENAI_API_KEY

    def _get_client(self):
        from openai import AsyncOpenAI
        return AsyncOpenAI(api_key=self.api_key)

    async def stream_chat(
        self,
        messages: list[dict],
        model: str,
        system: str | None,
        temperature: float,
        top_p: float,
        max_tokens: int,
    ) -> AsyncIterator[str]:
        client = self._get_client()
        all_messages = []
        if system:
            all_messages.append({"role": "system", "content": system})
        all_messages.extend(messages)

        stream = await client.chat.completions.create(
            model=model,
            messages=all_messages,
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
            stream=True,
        )
        async for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                yield delta

    async def list_models(self) -> list[str]:
        return ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo"]

    async def health_check(self) -> bool:
        return bool(self.api_key)
