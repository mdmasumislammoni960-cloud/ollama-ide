import asyncio
import sys
from pathlib import Path
from app.core import config

LANGUAGE_RUNNERS = {
    ".py": [sys.executable],
    ".js": ["node"],
    ".ts": ["ts-node"],
    ".sh": ["bash"],
    ".rb": ["ruby"],
    ".go": ["go", "run"],
}


async def run_file(path: Path) -> str:
    suffix = path.suffix.lower()
    runner = LANGUAGE_RUNNERS.get(suffix)
    if not runner:
        return f"Error: unsupported file type '{suffix}'"

    cmd = runner + [str(path)]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
            cwd=path.parent,
        )
        stdout, _ = await asyncio.wait_for(
            proc.communicate(),
            timeout=config.MAX_EXEC_TIMEOUT
        )
        output = stdout.decode(errors="replace")
        return output if output else "(no output)"
    except asyncio.TimeoutError:
        try:
            proc.kill()
        except Exception:
            pass
        return f"Error: execution timed out after {config.MAX_EXEC_TIMEOUT}s"
    except FileNotFoundError:
        return f"Error: runtime not found for '{suffix}' (is {runner[0]} installed?)"
    except Exception as e:
        return f"Error: {str(e)}"
