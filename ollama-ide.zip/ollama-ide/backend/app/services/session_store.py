import sqlite3
import json
import uuid
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).parent.parent.parent / "sessions.db"


def _conn():
    con = sqlite3.connect(str(DB_PATH))
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with _conn() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY,
                title TEXT,
                created_at TEXT,
                updated_at TEXT,
                messages TEXT,
                provider TEXT,
                model TEXT
            )
        """)
        con.commit()


def create_session(provider: str, model: str, first_message: str = "") -> dict:
    sid = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()
    title = (first_message[:40] + "…") if len(first_message) > 40 else first_message or "New Session"
    with _conn() as con:
        con.execute(
            "INSERT INTO sessions VALUES (?,?,?,?,?,?,?)",
            (sid, title, now, now, "[]", provider, model),
        )
        con.commit()
    return get_session(sid)


def get_session(sid: str) -> dict | None:
    with _conn() as con:
        row = con.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["messages"] = json.loads(d["messages"])
    return d


def list_sessions() -> list[dict]:
    with _conn() as con:
        rows = con.execute("SELECT * FROM sessions ORDER BY updated_at DESC").fetchall()
    result = []
    for row in rows:
        d = dict(row)
        d["messages"] = json.loads(d["messages"])
        result.append(d)
    return result


def update_session_messages(sid: str, messages: list[dict]) -> bool:
    now = datetime.utcnow().isoformat()
    with _conn() as con:
        cur = con.execute(
            "UPDATE sessions SET messages=?, updated_at=? WHERE id=?",
            (json.dumps(messages), now, sid),
        )
        con.commit()
    return cur.rowcount > 0


def delete_session(sid: str) -> bool:
    with _conn() as con:
        cur = con.execute("DELETE FROM sessions WHERE id=?", (sid,))
        con.commit()
    return cur.rowcount > 0


# Initialize on import
init_db()
