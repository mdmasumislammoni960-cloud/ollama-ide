from pathlib import Path
from app.core import config


def _get_repo(path: Path):
    try:
        import git
        return git.Repo(path, search_parent_directories=True)
    except Exception:
        return None


def get_branch() -> str:
    repo = _get_repo(Path(config.WORKSPACE_ROOT))
    if not repo:
        return "unknown"
    try:
        return repo.active_branch.name
    except TypeError:
        return repo.head.commit.hexsha[:7]  # detached HEAD


def get_file_status() -> dict[str, str]:
    """Returns {relative_path: status} where status is M/U/A/D."""
    repo = _get_repo(Path(config.WORKSPACE_ROOT))
    if not repo:
        return {}

    result: dict[str, str] = {}
    try:
        # Modified / staged
        for item in repo.index.diff(None):          # unstaged changes
            result[item.a_path] = "M"
        for item in repo.index.diff("HEAD"):         # staged changes
            result[item.a_path] = "A"
        # Untracked
        for path in repo.untracked_files:
            result[path] = "U"
        # Deleted
        for item in repo.index.diff(None, R=True):
            result[item.a_path] = "D"
    except Exception:
        pass
    return result
