from pydantic import BaseModel


class ApiKeyUpdate(BaseModel):
    provider: str
    api_key: str


class OllamaUrlUpdate(BaseModel):
    url: str


class WorkspaceUpdate(BaseModel):
    path: str
