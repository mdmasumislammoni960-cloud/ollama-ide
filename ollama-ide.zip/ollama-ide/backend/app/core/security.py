from pathlib import Path
from fastapi import HTTPException
from app.core import config


def safe_path(user_path: str) -> Path:
    """Resolve and jail a user-supplied path inside WORKSPACE_ROOT."""
    root = Path(config.WORKSPACE_ROOT).resolve()
    # Strip leading slashes/dots so joining works correctly
    clean = user_path.lstrip("/").lstrip("./")
    full = (root / clean).resolve()
    # Use is_relative_to (Python 3.9+) to avoid prefix collision bugs
    try:
        full.relative_to(root)
    except ValueError:
        raise HTTPException(status_code=403, detail="Path traversal denied")
    return full
