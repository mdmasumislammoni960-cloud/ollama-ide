import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

OLLAMA_BASE_URL: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
GOOGLE_API_KEY: str = os.getenv("GOOGLE_API_KEY", "")
GROQ_API_KEY: str = os.getenv("GROQ_API_KEY", "")
WORKSPACE_ROOT: str = os.getenv("WORKSPACE_ROOT", str(Path(__file__).parent.parent.parent / "workspace"))
MAX_EXEC_TIMEOUT: int = int(os.getenv("MAX_EXEC_TIMEOUT", "10"))
