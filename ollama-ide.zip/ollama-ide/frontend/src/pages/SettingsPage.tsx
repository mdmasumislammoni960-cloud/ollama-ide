import { useState, useEffect } from 'react'
import { useSettings } from '@/context/SettingsContext'
import { saveApiKey, setOllamaUrl, fetchOllamaHealth, fetchWorkspace, setWorkspace } from '@/api/settings'
import { Check, Eye, EyeOff, RefreshCw, Save } from 'lucide-react'

const CLOUD_PROVIDERS = [
  { key: 'anthropic', label: 'Anthropic', placeholder: 'sk-ant-…' },
  { key: 'openai',    label: 'OpenAI',    placeholder: 'sk-…'     },
  { key: 'google',    label: 'Google',    placeholder: 'AIza…'    },
  { key: 'groq',      label: 'Groq',      placeholder: 'gsk_…'    },
]

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{
      background: 'var(--bg2)', border: '1px solid var(--border)',
      borderRadius: 8, padding: '18px 20px', display: 'flex', flexDirection: 'column', gap: 14,
    }}>
      <h2 style={{ fontSize: 13, fontWeight: 600, color: 'var(--fg2)',
        textTransform: 'uppercase', letterSpacing: '0.07em', margin: 0 }}>
        {title}
      </h2>
      {children}
    </div>
  )
}

function ApiKeyRow({ label, providerKey, placeholder, status }: {
  label: string; providerKey: string; placeholder: string
  status: Record<string, boolean>
}) {
  const [value, setValue] = useState('')
  const [show, setShow] = useState(false)
  const [saved, setSaved] = useState(false)

  const handleSave = async () => {
    if (!value.trim()) return
    await saveApiKey(providerKey, value)
    setValue('')
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const active = status[providerKey]

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ fontSize: 13, fontWeight: 500, color: 'var(--fg)', minWidth: 90 }}>{label}</span>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 4, fontSize: 11,
          color: active ? 'var(--green)' : 'var(--fg3)',
        }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%',
            background: active ? 'var(--green)' : 'var(--fg3)' }} />
          {active ? 'active' : 'not set'}
        </div>
      </div>
      <div style={{ display: 'flex', gap: 6 }}>
        <div style={{
          flex: 1, display: 'flex', alignItems: 'center',
          background: 'var(--bg)', border: '1px solid var(--border)',
          borderRadius: 'var(--radius)', overflow: 'hidden',
        }}>
          <input
            type={show ? 'text' : 'password'}
            value={value}
            onChange={e => setValue(e.target.value)}
            placeholder={placeholder}
            style={{
              flex: 1, padding: '7px 10px', background: 'none',
              border: 'none', outline: 'none', color: 'var(--fg)',
              fontSize: 13, fontFamily: "'JetBrains Mono', monospace",
            }}
          />
          <button onClick={() => setShow(s => !s)}
            style={{ padding: '0 10px', background: 'none', border: 'none',
              cursor: 'pointer', color: 'var(--fg3)' }}>
            {show ? <EyeOff size={13} /> : <Eye size={13} />}
          </button>
        </div>
        <button onClick={handleSave} disabled={!value.trim()}
          style={{
            padding: '7px 14px', border: 'none', borderRadius: 'var(--radius)',
            background: saved ? 'var(--green)' : 'var(--accent)',
            color: '#fff', cursor: value.trim() ? 'pointer' : 'not-allowed',
            fontSize: 12, display: 'flex', alignItems: 'center', gap: 4,
            opacity: !value.trim() ? 0.5 : 1,
            transition: 'background 0.2s',
          }}>
          {saved ? <><Check size={12} /> Saved</> : <><Save size={12} /> Save</>}
        </button>
      </div>
    </div>
  )
}

export default function SettingsPage() {
  const { theme, toggleTheme, providerStatus, refreshProviderStatus } = useSettings()
  const [ollamaUrl, setOllamaUrlState] = useState('http://localhost:11434')
  const [ollamaHealth, setOllamaHealth] = useState<{ status: string; models?: string[] } | null>(null)
  const [checkingOllama, setCheckingOllama] = useState(false)
  const [workspacePath, setWorkspacePath] = useState('')
  const [wsSaved, setWsSaved] = useState(false)

  useEffect(() => {
    fetchWorkspace().then(setWorkspacePath).catch(() => {})
  }, [])

  const checkOllama = async () => {
    setCheckingOllama(true)
    try {
      const h = await fetchOllamaHealth()
      setOllamaHealth(h)
    } catch {
      setOllamaHealth({ status: 'error' })
    } finally {
      setCheckingOllama(false)
    }
  }

  useEffect(() => { checkOllama() }, [])

  const saveOllamaUrl = async () => {
    await setOllamaUrl(ollamaUrl)
    await checkOllama()
  }

  const saveWorkspace = async () => {
    await setWorkspace(workspacePath)
    setWsSaved(true)
    setTimeout(() => setWsSaved(false), 2000)
  }

  const inputStyle: React.CSSProperties = {
    flex: 1, padding: '7px 10px',
    background: 'var(--bg)', border: '1px solid var(--border)',
    borderRadius: 'var(--radius)', color: 'var(--fg)',
    fontSize: 13, fontFamily: "'JetBrains Mono', monospace",
    outline: 'none',
  }

  return (
    <div style={{ height: '100%', overflowY: 'auto', padding: '24px 0' }}>
      <div style={{ maxWidth: 680, margin: '0 auto', padding: '0 24px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        <h1 style={{ fontFamily: "'Space Grotesk', sans-serif", fontSize: 22, fontWeight: 700, color: 'var(--fg)', margin: 0 }}>
          Settings
        </h1>

        {/* Ollama */}
        <Section title="Ollama">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{
              width: 8, height: 8, borderRadius: '50%',
              background: ollamaHealth?.status === 'ok' ? 'var(--green)' : 'var(--red)',
              boxShadow: ollamaHealth?.status === 'ok' ? '0 0 6px var(--green)' : undefined,
            }} />
            <span style={{ fontSize: 13, color: ollamaHealth?.status === 'ok' ? 'var(--green)' : 'var(--red)' }}>
              {ollamaHealth?.status === 'ok'
                ? `Connected · ${ollamaHealth.models?.length ?? 0} models available`
                : 'Not connected'}
            </span>
            <button onClick={checkOllama}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fg3)', marginLeft: 4 }}>
              <RefreshCw size={13} style={{ animation: checkingOllama ? 'spin 0.8s linear infinite' : undefined }} />
            </button>
          </div>

          <div style={{ display: 'flex', gap: 6 }}>
            <input style={inputStyle} value={ollamaUrl}
              onChange={e => setOllamaUrlState(e.target.value)}
              placeholder="http://localhost:11434" />
            <button onClick={saveOllamaUrl}
              style={{ padding: '7px 14px', background: 'var(--accent)', color: '#fff',
                border: 'none', borderRadius: 'var(--radius)', cursor: 'pointer', fontSize: 13 }}>
              Update
            </button>
          </div>

          {ollamaHealth?.models && ollamaHealth.models.length > 0 && (
            <div>
              <div style={{ fontSize: 12, color: 'var(--fg3)', marginBottom: 6 }}>Available models:</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {ollamaHealth.models.map(m => (
                  <span key={m} style={{
                    fontSize: 11, padding: '3px 8px',
                    background: 'var(--bg3)', border: '1px solid var(--border)',
                    borderRadius: 4, color: 'var(--fg2)', fontFamily: "'JetBrains Mono', monospace",
                  }}>{m}</span>
                ))}
              </div>
            </div>
          )}
        </Section>

        {/* Cloud providers */}
        <Section title="Cloud Providers">
          <p style={{ fontSize: 12, color: 'var(--fg3)', margin: 0 }}>
            API keys are stored in memory only — never persisted or returned by the API.
          </p>
          {CLOUD_PROVIDERS.map(p => (
            <ApiKeyRow key={p.key} label={p.label} providerKey={p.key}
              placeholder={p.placeholder} status={providerStatus} />
          ))}
          <button onClick={refreshProviderStatus}
            style={{ alignSelf: 'flex-start', display: 'flex', alignItems: 'center', gap: 5,
              padding: '6px 12px', background: 'none', border: '1px solid var(--border)',
              borderRadius: 'var(--radius)', cursor: 'pointer', color: 'var(--fg2)', fontSize: 12 }}>
            <RefreshCw size={12} /> Refresh status
          </button>
        </Section>

        {/* Workspace */}
        <Section title="Workspace">
          <p style={{ fontSize: 12, color: 'var(--fg3)', margin: 0 }}>
            Root folder for the file tree and code execution.
          </p>
          <div style={{ display: 'flex', gap: 6 }}>
            <input style={inputStyle} value={workspacePath}
              onChange={e => setWorkspacePath(e.target.value)}
              placeholder="/path/to/workspace" />
            <button onClick={saveWorkspace}
              style={{
                padding: '7px 14px', border: 'none', borderRadius: 'var(--radius)',
                background: wsSaved ? 'var(--green)' : 'var(--accent)',
                color: '#fff', cursor: 'pointer', fontSize: 13,
                display: 'flex', alignItems: 'center', gap: 4, transition: 'background 0.2s',
              }}>
              {wsSaved ? <><Check size={13} /> Saved</> : <><Save size={13} /> Save</>}
            </button>
          </div>
        </Section>

        {/* Appearance */}
        <Section title="Appearance">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: 13, color: 'var(--fg)' }}>Theme</span>
            <div style={{ display: 'flex', gap: 6 }}>
              {(['dark', 'light'] as const).map(t => (
                <button key={t} onClick={() => t !== theme && toggleTheme()}
                  style={{
                    padding: '6px 14px', borderRadius: 'var(--radius)', cursor: 'pointer',
                    border: '1px solid', fontSize: 13, transition: 'all 0.15s',
                    background: theme === t ? 'var(--accent)' : 'var(--bg)',
                    borderColor: theme === t ? 'var(--accent)' : 'var(--border)',
                    color: theme === t ? '#fff' : 'var(--fg2)',
                  }}>
                  {t.charAt(0).toUpperCase() + t.slice(1)}
                </button>
              ))}
            </div>
          </div>
        </Section>
      </div>
    </div>
  )
}
