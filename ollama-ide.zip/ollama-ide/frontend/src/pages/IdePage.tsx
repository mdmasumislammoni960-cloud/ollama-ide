import { useState, useCallback } from 'react'
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels'
import { useSettings } from '@/context/SettingsContext'
import { useEditor } from '@/hooks/useEditor'
import FileTree from '@/components/editor/FileTree'
import TabBar from '@/components/editor/TabBar'
import MonacoEditor from '@/components/editor/MonacoEditor'
import Terminal from '@/components/editor/Terminal'
import ChatPanel from '@/components/chat/ChatPanel'
import { Play, Save, Terminal as TermIcon } from 'lucide-react'

export default function IdePage() {
  const { theme } = useSettings()
  const { tabs, activeTab, activeTabData, openFile, closeTab, updateContent, saveTab, setActiveTab } = useEditor()
  const [showTerminal, setShowTerminal] = useState(false)
  const [runPath, setRunPath] = useState<string | null>(null)

  const handleRun = useCallback(() => {
    if (!activeTab) return
    setShowTerminal(true)
    setRunPath(null)
    setTimeout(() => setRunPath(activeTab), 50) // force re-trigger
  }, [activeTab])

  const handleSave = useCallback(() => {
    if (activeTab) saveTab(activeTab)
  }, [activeTab, saveTab])

  const handleChange = useCallback((v: string) => {
    if (activeTab) updateContent(activeTab, v)
  }, [activeTab, updateContent])

  const divider = (
    <PanelResizeHandle style={{
      width: 4, background: 'var(--border)', cursor: 'col-resize',
      transition: 'background 0.15s', flexShrink: 0,
    }} />
  )

  const hDivider = (
    <PanelResizeHandle style={{
      height: 4, background: 'var(--border)', cursor: 'row-resize',
      transition: 'background 0.15s', flexShrink: 0,
    }} />
  )

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Toolbar */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '5px 12px', height: 38,
        background: 'var(--bg2)', borderBottom: '1px solid var(--border)',
        flexShrink: 0,
      }}>
        <div style={{ display: 'flex', gap: 6 }}>
          <button onClick={handleSave} disabled={!activeTab}
            title="Save (Ctrl+S)"
            style={{ ...toolBtn, opacity: !activeTab ? 0.4 : 1 }}>
            <Save size={13} /> Save
          </button>
          <button onClick={handleRun} disabled={!activeTab}
            title="Run file"
            style={{ ...toolBtn, opacity: !activeTab ? 0.4 : 1,
              background: activeTab ? 'color-mix(in srgb, var(--green) 15%, transparent)' : undefined,
              borderColor: activeTab ? 'var(--green)' : 'var(--border)',
              color: activeTab ? 'var(--green)' : 'var(--fg2)',
            }}>
            <Play size={13} /> Run
          </button>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button onClick={() => setShowTerminal(t => !t)} title="Toggle terminal"
            style={{ ...toolBtn, color: showTerminal ? 'var(--accent)' : 'var(--fg2)',
              borderColor: showTerminal ? 'var(--accent)' : 'var(--border)' }}>
            <TermIcon size={13} /> Terminal
          </button>
        </div>
      </div>

      {/* Main panels */}
      <div style={{ flex: 1, overflow: 'hidden' }}>
        <PanelGroup direction="horizontal" style={{ height: '100%' }}>
          {/* Left: File tree */}
          <Panel defaultSize={18} minSize={12} maxSize={35}>
            <FileTree onOpenFile={openFile} activeFile={activeTab} />
          </Panel>

          {divider}

          {/* Center: Editor + Terminal */}
          <Panel defaultSize={55} minSize={30}>
            <PanelGroup direction="vertical" style={{ height: '100%' }}>
              <Panel defaultSize={showTerminal ? 70 : 100} minSize={30}>
                <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                  <TabBar tabs={tabs} activeTab={activeTab}
                    onActivate={setActiveTab} onClose={closeTab} />
                  <div style={{ flex: 1, overflow: 'hidden' }}>
                    <MonacoEditor
                      tab={activeTabData}
                      theme={theme}
                      onChange={handleChange}
                      onSave={handleSave}
                    />
                  </div>
                </div>
              </Panel>

              {showTerminal && (
                <>
                  {hDivider}
                  <Panel defaultSize={30} minSize={15} maxSize={60}>
                    <Terminal onClose={() => setShowTerminal(false)} runPath={runPath} />
                  </Panel>
                </>
              )}
            </PanelGroup>
          </Panel>

          {divider}

          {/* Right: Chat */}
          <Panel defaultSize={27} minSize={20} maxSize={45}>
            <ChatPanel compact />
          </Panel>
        </PanelGroup>
      </div>
    </div>
  )
}

const toolBtn: React.CSSProperties = {
  display: 'flex', alignItems: 'center', gap: 5,
  padding: '4px 10px', background: 'none',
  border: '1px solid var(--border)', borderRadius: 'var(--radius)',
  cursor: 'pointer', color: 'var(--fg2)', fontSize: 12,
  transition: 'all 0.15s',
}
