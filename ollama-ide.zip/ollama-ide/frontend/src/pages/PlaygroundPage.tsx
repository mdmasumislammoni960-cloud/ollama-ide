import { useState } from 'react'
import { useSession } from '@/context/SessionContext'
import ChatPanel from '@/components/chat/ChatPanel'
import { Clock, Trash2, Plus, MessageSquare } from 'lucide-react'

export default function PlaygroundPage() {
  const { sessions, activeSession, setActiveSession, deleteSession, createSession, setMessages, clearMessages } = useSession()
  const [showHistory, setShowHistory] = useState(true)

  const switchSession = (s: typeof sessions[0]) => {
    setActiveSession(s)
    setMessages(s.messages)
  }

  const handleNew = () => {
    clearMessages()
    createSession('ollama', 'llama3.2')
  }

  return (
    <div style={{ height: '100%', display: 'flex', background: 'var(--bg)' }}>
      {/* Session sidebar */}
      {showHistory && (
        <div style={{
          width: 220, flexShrink: 0,
          background: 'var(--bg2)', borderRight: '1px solid var(--border)',
          display: 'flex', flexDirection: 'column',
        }}>
          <div style={{
            padding: '10px 12px', borderBottom: '1px solid var(--border)',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            flexShrink: 0,
          }}>
            <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--fg3)',
              textTransform: 'uppercase', letterSpacing: '0.07em' }}>
              History
            </span>
            <button onClick={handleNew} title="New session"
              style={{
                background: 'none', border: '1px solid var(--border)', borderRadius: 4,
                cursor: 'pointer', color: 'var(--fg2)', padding: '3px 6px',
                display: 'flex', alignItems: 'center', gap: 3, fontSize: 11,
              }}>
              <Plus size={11} /> New
            </button>
          </div>

          <div style={{ flex: 1, overflowY: 'auto', padding: '6px 0' }}>
            {sessions.length === 0 && (
              <div style={{ padding: '20px 12px', color: 'var(--fg3)', fontSize: 12, textAlign: 'center' }}>
                No sessions yet
              </div>
            )}
            {sessions.map(s => (
              <div key={s.id}
                onClick={() => switchSession(s)}
                style={{
                  padding: '8px 12px', cursor: 'pointer',
                  background: activeSession?.id === s.id
                    ? 'color-mix(in srgb, var(--accent) 12%, transparent)' : 'none',
                  borderLeft: activeSession?.id === s.id ? '2px solid var(--accent)' : '2px solid transparent',
                  display: 'flex', flexDirection: 'column', gap: 3,
                }}
                onMouseEnter={e => { if (activeSession?.id !== s.id) (e.currentTarget as HTMLElement).style.background = 'var(--bg3)' }}
                onMouseLeave={e => { if (activeSession?.id !== s.id) (e.currentTarget as HTMLElement).style.background = 'none' }}
              >
                <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 4 }}>
                  <div style={{
                    display: 'flex', alignItems: 'center', gap: 4,
                    fontSize: 12.5, color: 'var(--fg)',
                    flex: 1, minWidth: 0,
                  }}>
                    <MessageSquare size={11} style={{ flexShrink: 0 }} />
                    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {s.title}
                    </span>
                  </div>
                  <button
                    onClick={e => { e.stopPropagation(); deleteSession(s.id) }}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fg3)',
                      padding: 2, flexShrink: 0, display: 'flex' }}>
                    <Trash2 size={11} />
                  </button>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: 'var(--fg3)' }}>
                  <Clock size={10} />
                  {new Date(s.updated_at).toLocaleDateString()}
                  <span>·</span>
                  <span>{s.messages.length} msgs</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Chat area */}
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <ChatPanel />
      </div>
    </div>
  )
}
