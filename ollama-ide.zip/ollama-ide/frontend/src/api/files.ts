import type { FileNode, GitStatus } from '@/types'

const BASE = '/api/files'

export async function fetchTree(): Promise<{ tree: FileNode; branch: string }> {
  const resp = await fetch(`${BASE}/tree`)
  if (!resp.ok) throw new Error('Failed to fetch tree')
  return resp.json()
}

export async function readFile(path: string): Promise<string> {
  const resp = await fetch(`${BASE}/read?path=${encodeURIComponent(path)}`)
  if (!resp.ok) throw new Error(`Failed to read ${path}`)
  const data = await resp.json()
  return data.content
}

export async function writeFile(path: string, content: string): Promise<void> {
  const resp = await fetch(`${BASE}/write`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path, content }),
  })
  if (!resp.ok) throw new Error(`Failed to write ${path}`)
}

export async function runFile(path: string): Promise<string> {
  const resp = await fetch(`${BASE}/run`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path }),
  })
  if (!resp.ok) throw new Error(`Failed to run ${path}`)
  const data = await resp.json()
  return data.output
}

export async function fetchGitStatus(): Promise<GitStatus> {
  const resp = await fetch(`${BASE}/git-status`)
  if (!resp.ok) return { branch: 'unknown', status: {} }
  return resp.json()
}

export async function deleteFile(path: string): Promise<void> {
  await fetch(`${BASE}/delete?path=${encodeURIComponent(path)}`, { method: 'DELETE' })
}

export async function createDir(path: string): Promise<void> {
  await fetch(`${BASE}/mkdir`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path, content: '' }),
  })
}
