import type { Message, ModelControls } from '@/types'

const BASE = '/api'

export async function* streamChat(
  controls: ModelControls,
  messages: Message[],
  signal?: AbortSignal
): AsyncGenerator<string> {
  const body = JSON.stringify({
    provider: controls.provider,
    model: controls.model,
    system: controls.system || null,
    temperature: controls.temperature,
    top_p: controls.top_p,
    max_tokens: controls.max_tokens,
    messages: messages.map((m) => ({ role: m.role, content: m.content })),
  })

  const resp = await fetch(`${BASE}/chat/stream`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body,
    signal,
  })

  if (!resp.ok) {
    throw new Error(`HTTP ${resp.status}: ${await resp.text()}`)
  }

  const reader = resp.body!.getReader()
  const decoder = new TextDecoder()
  let buffer = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })

    const lines = buffer.split('\n')
    buffer = lines.pop() ?? ''

    for (const line of lines) {
      if (!line.startsWith('data: ')) continue
      const payload = line.slice(6).trim()
      if (payload === '[DONE]') return
      try {
        const token = JSON.parse(payload)
        if (typeof token === 'string') yield token
        else if (token?.error) throw new Error(token.error)
      } catch {
        // skip malformed lines
      }
    }
  }
}

export async function fetchModels(provider: string): Promise<string[]> {
  const resp = await fetch(`${BASE}/chat/models/${provider}`)
  if (!resp.ok) return []
  const data = await resp.json()
  return data.models ?? []
}
