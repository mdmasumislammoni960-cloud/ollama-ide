import type { ProviderStatus } from '@/types'

const BASE = '/api'

export async function fetchProviderStatus(): Promise<ProviderStatus> {
  const resp = await fetch(`${BASE}/settings/providers`)
  if (!resp.ok) throw new Error('Failed to fetch provider status')
  return resp.json()
}

export async function saveApiKey(provider: string, api_key: string): Promise<void> {
  const resp = await fetch(`${BASE}/settings/api-key`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ provider, api_key }),
  })
  if (!resp.ok) throw new Error('Failed to save API key')
}

export async function fetchOllamaHealth(): Promise<{ status: string; models?: string[]; detail?: string }> {
  const resp = await fetch(`${BASE}/health/ollama`)
  return resp.json()
}

export async function setOllamaUrl(url: string): Promise<void> {
  await fetch(`${BASE}/settings/ollama-url`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url }),
  })
}

export async function fetchWorkspace(): Promise<string> {
  const resp = await fetch(`${BASE}/settings/workspace`)
  const data = await resp.json()
  return data.path
}

export async function setWorkspace(path: string): Promise<void> {
  await fetch(`${BASE}/settings/workspace`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ path }),
  })
}
