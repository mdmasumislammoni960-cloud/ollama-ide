import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { SettingsProvider } from '@/context/SettingsContext'
import { SessionProvider } from '@/context/SessionContext'
import Navbar from '@/components/ui/Navbar'
import PlaygroundPage from '@/pages/PlaygroundPage'
import IdePage from '@/pages/IdePage'
import SettingsPage from '@/pages/SettingsPage'

export default function App() {
  return (
    <SettingsProvider>
      <SessionProvider>
        <BrowserRouter>
          <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: 'var(--bg)' }}>
            <Navbar />
            <div style={{ flex: 1, overflow: 'hidden' }}>
              <Routes>
                <Route path="/" element={<Navigate to="/playground" replace />} />
                <Route path="/playground" element={<PlaygroundPage />} />
                <Route path="/ide" element={<IdePage />} />
                <Route path="/settings" element={<SettingsPage />} />
              </Routes>
            </div>
          </div>
        </BrowserRouter>
      </SessionProvider>
    </SettingsProvider>
  )
}
