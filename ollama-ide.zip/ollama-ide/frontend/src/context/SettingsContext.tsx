import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import type { Provider, ProviderStatus } from '@/types'
import { fetchProviderStatus } from '@/api/settings'

type Theme = 'dark' | 'light'

interface SettingsContextValue {
  theme: Theme
  toggleTheme: () => void
  provider: Provider
  setProvider: (p: Provider) => void
  providerStatus: ProviderStatus
  refreshProviderStatus: () => void
}

const SettingsContext = createContext<SettingsContextValue | null>(null)

const DEFAULT_STATUS: ProviderStatus = {
  ollama: false, anthropic: false, openai: false, google: false, groq: false,
}

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>(
    () => (localStorage.getItem('theme') as Theme) ?? 'dark'
  )
  const [provider, setProvider] = useState<Provider>(
    () => (localStorage.getItem('provider') as Provider) ?? 'ollama'
  )
  const [providerStatus, setProviderStatus] = useState<ProviderStatus>(DEFAULT_STATUS)

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme)
    localStorage.setItem('theme', theme)
  }, [theme])

  useEffect(() => {
    localStorage.setItem('provider', provider)
  }, [provider])

  const refreshProviderStatus = () => {
    fetchProviderStatus()
      .then(setProviderStatus)
      .catch(() => setProviderStatus(DEFAULT_STATUS))
  }

  useEffect(() => {
    refreshProviderStatus()
    const id = setInterval(refreshProviderStatus, 30_000)
    return () => clearInterval(id)
  }, [])

  const toggleTheme = () => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))

  return (
    <SettingsContext.Provider value={{ theme, toggleTheme, provider, setProvider, providerStatus, refreshProviderStatus }}>
      {children}
    </SettingsContext.Provider>
  )
}

export function useSettings() {
  const ctx = useContext(SettingsContext)
  if (!ctx) throw new Error('useSettings must be inside SettingsProvider')
  return ctx
}
