import { createContext, useContext, useState, useCallback, ReactNode } from 'react'
import type { Message, Session } from '@/types'

interface SessionContextValue {
  sessions: Session[]
  activeSession: Session | null
  setActiveSession: (s: Session | null) => void
  messages: Message[]
  setMessages: (msgs: Message[]) => void
  addMessage: (msg: Message) => void
  updateLastMessage: (content: string) => void
  createSession: (provider: string, model: string) => Session
  deleteSession: (id: string) => void
  clearMessages: () => void
}

const SessionContext = createContext<SessionContextValue | null>(null)

function makeSession(provider: string, model: string): Session {
  return {
    id: crypto.randomUUID(),
    title: 'New Session',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    messages: [],
    provider,
    model,
  }
}

export function SessionProvider({ children }: { children: ReactNode }) {
  const [sessions, setSessions] = useState<Session[]>([])
  const [activeSession, setActiveSession] = useState<Session | null>(null)
  const [messages, setMessages] = useState<Message[]>([])

  const addMessage = useCallback((msg: Message) => {
    setMessages((prev) => {
      const next = [...prev, msg]
      // Auto-title from first user message
      if (activeSession && msg.role === 'user' && prev.filter(m => m.role === 'user').length === 0) {
        const title = msg.content.slice(0, 40) + (msg.content.length > 40 ? '…' : '')
        setSessions((ss) => ss.map((s) => s.id === activeSession.id ? { ...s, title } : s))
      }
      return next
    })
  }, [activeSession])

  const updateLastMessage = useCallback((content: string) => {
    setMessages((prev) => {
      if (prev.length === 0) return prev
      const copy = [...prev]
      copy[copy.length - 1] = { ...copy[copy.length - 1], content }
      return copy
    })
  }, [])

  const createSession = useCallback((provider: string, model: string) => {
    const s = makeSession(provider, model)
    setSessions((prev) => [s, ...prev])
    setActiveSession(s)
    setMessages([])
    return s
  }, [])

  const deleteSession = useCallback((id: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== id))
    setActiveSession((prev) => (prev?.id === id ? null : prev))
  }, [])

  const clearMessages = useCallback(() => setMessages([]), [])

  return (
    <SessionContext.Provider value={{
      sessions, activeSession, setActiveSession,
      messages, setMessages, addMessage, updateLastMessage,
      createSession, deleteSession, clearMessages,
    }}>
      {children}
    </SessionContext.Provider>
  )
}

export function useSession() {
  const ctx = useContext(SessionContext)
  if (!ctx) throw new Error('useSession must be inside SessionProvider')
  return ctx
}
