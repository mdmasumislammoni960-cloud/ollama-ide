import { useState, useRef, useCallback } from 'react'
import type { Message, ModelControls } from '@/types'
import { streamChat } from '@/api/chat'
import { useSession } from '@/context/SessionContext'

export function useChat(controls: ModelControls) {
  const [streaming, setStreaming] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const abortRef = useRef<AbortController | null>(null)
  const { messages, addMessage, updateLastMessage } = useSession()

  const send = useCallback(async (userText: string) => {
    if (!userText.trim() || streaming) return
    setError(null)

    const userMsg: Message = {
      id: crypto.randomUUID(),
      role: 'user',
      content: userText.trim(),
      timestamp: Date.now(),
    }
    addMessage(userMsg)

    const assistantMsg: Message = {
      id: crypto.randomUUID(),
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
    }
    addMessage(assistantMsg)

    const allMessages = [...messages, userMsg]
    abortRef.current = new AbortController()
    setStreaming(true)

    let accumulated = ''
    try {
      for await (const token of streamChat(controls, allMessages, abortRef.current.signal)) {
        accumulated += token
        updateLastMessage(accumulated)
      }
    } catch (e: unknown) {
      if (e instanceof Error && e.name !== 'AbortError') {
        setError(e.message)
        updateLastMessage(`[Error: ${e.message}]`)
      }
    } finally {
      setStreaming(false)
      abortRef.current = null
    }
  }, [streaming, controls, messages, addMessage, updateLastMessage])

  const stop = useCallback(() => {
    abortRef.current?.abort()
  }, [])

  return { send, stop, streaming, error }
}
