import { useState, useEffect, useCallback } from 'react'
import type { Provider } from '@/types'
import { fetchModels } from '@/api/chat'

const MODEL_CACHE: Record<string, string[]> = {}

export function useProviders(provider: Provider) {
  const [models, setModels] = useState<string[]>(MODEL_CACHE[provider] ?? [])
  const [loading, setLoading] = useState(false)

  const refresh = useCallback(async () => {
    setLoading(true)
    try {
      const list = await fetchModels(provider)
      MODEL_CACHE[provider] = list
      setModels(list)
    } catch {
      setModels([])
    } finally {
      setLoading(false)
    }
  }, [provider])

  useEffect(() => {
    refresh()
  }, [refresh])

  return { models, loading, refresh }
}
