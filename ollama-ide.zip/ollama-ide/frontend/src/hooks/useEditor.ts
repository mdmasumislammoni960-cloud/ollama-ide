import { useState, useCallback } from 'react'
import type { Tab } from '@/types'
import { readFile, writeFile } from '@/api/files'

function getLanguage(filename: string): string {
  const ext = filename.split('.').pop()?.toLowerCase() ?? ''
  const map: Record<string, string> = {
    ts: 'typescript', tsx: 'typescript', js: 'javascript', jsx: 'javascript',
    py: 'python', rb: 'ruby', go: 'go', rs: 'rust', java: 'java',
    cpp: 'cpp', c: 'c', cs: 'csharp', php: 'php', swift: 'swift',
    html: 'html', css: 'css', scss: 'scss', json: 'json', yaml: 'yaml',
    yml: 'yaml', md: 'markdown', sh: 'shell', bash: 'shell',
    sql: 'sql', xml: 'xml', toml: 'toml', env: 'ini',
  }
  return map[ext] ?? 'plaintext'
}

export function useEditor() {
  const [tabs, setTabs] = useState<Tab[]>([])
  const [activeTab, setActiveTab] = useState<string | null>(null)

  const openFile = useCallback(async (path: string) => {
    const existing = tabs.find((t) => t.path === path)
    if (existing) {
      setActiveTab(path)
      return
    }
    const content = await readFile(path)
    const name = path.split('/').pop() ?? path
    const tab: Tab = { path, name, content, dirty: false, language: getLanguage(name) }
    setTabs((prev) => [...prev, tab])
    setActiveTab(path)
  }, [tabs])

  const closeTab = useCallback((path: string) => {
    setTabs((prev) => {
      const next = prev.filter((t) => t.path !== path)
      return next
    })
    setActiveTab((prev) => {
      if (prev !== path) return prev
      const remaining = tabs.filter((t) => t.path !== path)
      return remaining.at(-1)?.path ?? null
    })
  }, [tabs])

  const updateContent = useCallback((path: string, content: string) => {
    setTabs((prev) => prev.map((t) => t.path === path ? { ...t, content, dirty: true } : t))
  }, [])

  const saveTab = useCallback(async (path: string) => {
    const tab = tabs.find((t) => t.path === path)
    if (!tab) return
    await writeFile(path, tab.content)
    setTabs((prev) => prev.map((t) => t.path === path ? { ...t, dirty: false } : t))
  }, [tabs])

  const activeTabData = tabs.find((t) => t.path === activeTab) ?? null

  return { tabs, activeTab, activeTabData, openFile, closeTab, updateContent, saveTab, setActiveTab }
}
