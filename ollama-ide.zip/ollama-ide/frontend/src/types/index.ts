export type Role = 'user' | 'assistant' | 'system'

export interface Message {
  id: string
  role: Role
  content: string
  timestamp: number
}

export interface Session {
  id: string
  title: string
  created_at: string
  updated_at: string
  messages: Message[]
  provider: string
  model: string
}

export type Provider = 'ollama' | 'anthropic' | 'openai' | 'google' | 'groq'

export interface ModelControls {
  provider: Provider
  model: string
  temperature: number
  top_p: number
  max_tokens: number
  system: string
}

export interface FileNode {
  name: string
  path: string
  type: 'file' | 'directory'
  children?: FileNode[]
}

export interface GitStatus {
  branch: string
  status: Record<string, 'M' | 'U' | 'A' | 'D'>
}

export interface ProviderStatus {
  ollama: boolean
  anthropic: boolean
  openai: boolean
  google: boolean
  groq: boolean
}

export interface Tab {
  path: string
  name: string
  content: string
  dirty: boolean
  language: string
}
