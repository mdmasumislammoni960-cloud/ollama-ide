import { NavLink } from 'react-router-dom'
import OllamaStatus from './OllamaStatus'
import ThemeToggle from './ThemeToggle'
import { Terminal, MessageSquare, Settings } from 'lucide-react'

const NAV_ITEMS = [
  { to: '/playground', label: 'Playground', icon: MessageSquare },
  { to: '/ide',        label: 'IDE',         icon: Terminal },
  { to: '/settings',  label: 'Settings',    icon: Settings },
]

export default function Navbar() {
  return (
    <header style={{
      height: 48,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 16px',
      background: 'var(--bg2)',
      borderBottom: '1px solid var(--border)',
      flexShrink: 0,
      zIndex: 50,
    }}>
      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 26, height: 26, borderRadius: 6,
          background: 'linear-gradient(135deg, var(--accent), var(--accent2))',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 13, fontWeight: 700, color: '#fff',
          fontFamily: "'Space Grotesk', sans-serif",
        }}>O</div>
        <span style={{
          fontFamily: "'Space Grotesk', sans-serif",
          fontWeight: 600, fontSize: 15, color: 'var(--fg)',
          letterSpacing: '-0.3px',
        }}>
          Ollama <span style={{ color: 'var(--accent)' }}>IDE</span>
        </span>
      </div>

      {/* Nav links */}
      <nav style={{ display: 'flex', gap: 2 }}>
        {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
          <NavLink key={to} to={to} style={({ isActive }) => ({
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '5px 12px', borderRadius: 'var(--radius)',
            fontSize: 13, fontWeight: 500, textDecoration: 'none',
            transition: 'all 0.15s',
            color: isActive ? 'var(--accent)' : 'var(--fg2)',
            background: isActive ? 'color-mix(in srgb, var(--accent) 12%, transparent)' : 'none',
          })}>
            <Icon size={13} />
            {label}
          </NavLink>
        ))}
      </nav>

      {/* Right side */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <OllamaStatus />
        <ThemeToggle />
      </div>
    </header>
  )
}
