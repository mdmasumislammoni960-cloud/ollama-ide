import { useState, useEffect } from 'react'
import { fetchOllamaHealth } from '@/api/settings'

export default function OllamaStatus() {
  const [status, setStatus] = useState<'checking' | 'ok' | 'error'>('checking')
  const [tooltip, setTooltip] = useState('')
  const [show, setShow] = useState(false)

  const check = async () => {
    try {
      const data = await fetchOllamaHealth()
      if (data.status === 'ok') {
        setStatus('ok')
        setTooltip(`Ollama online · ${data.models?.length ?? 0} models`)
      } else {
        setStatus('error')
        setTooltip(data.detail ?? 'Ollama offline')
      }
    } catch {
      setStatus('error')
      setTooltip('Cannot reach backend')
    }
  }

  useEffect(() => {
    check()
    const id = setInterval(check, 15_000)
    return () => clearInterval(id)
  }, [])

  const colors = { checking: 'var(--yellow)', ok: 'var(--green)', error: 'var(--red)' }

  return (
    <div style={{ position: 'relative' }}
      onMouseEnter={() => setShow(true)}
      onMouseLeave={() => setShow(false)}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'default' }} onClick={check}>
        <div style={{
          width: 8, height: 8, borderRadius: '50%',
          background: colors[status],
          boxShadow: status === 'ok' ? `0 0 6px var(--green)` : undefined,
          animation: status === 'checking' ? 'pulse 1.5s ease-in-out infinite' : undefined,
        }} />
        <span style={{ fontSize: 12, color: 'var(--fg2)', fontFamily: 'var(--font-mono)' }}>
          ollama
        </span>
      </div>
      {show && tooltip && (
        <div style={{
          position: 'absolute', top: '100%', right: 0, marginTop: 6,
          background: 'var(--bg3)', border: '1px solid var(--border)',
          borderRadius: 'var(--radius)', padding: '6px 10px',
          fontSize: 12, color: 'var(--fg2)', whiteSpace: 'nowrap',
          zIndex: 100, pointerEvents: 'none',
        }}>
          {tooltip}
        </div>
      )}
    </div>
  )
}
