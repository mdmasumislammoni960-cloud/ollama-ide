// Re-exports react-resizable-panels for convenience
export { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels'
