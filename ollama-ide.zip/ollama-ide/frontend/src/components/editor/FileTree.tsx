import { useState, useEffect } from 'react'
import type { FileNode, GitStatus } from '@/types'
import { fetchTree, fetchGitStatus } from '@/api/files'
import { Folder, FolderOpen, FileText, RefreshCw, GitBranch } from 'lucide-react'

const STATUS_COLORS: Record<string, string> = {
  M: 'var(--yellow)',
  U: 'var(--green)',
  A: 'var(--blue)',
  D: 'var(--red)',
}

interface Props {
  onOpenFile: (path: string) => void
  activeFile: string | null
}

function TreeNode({
  node, depth, onOpenFile, activeFile, gitStatus,
}: {
  node: FileNode; depth: number; onOpenFile: (p: string) => void
  activeFile: string | null; gitStatus: Record<string, string>
}) {
  const [expanded, setExpanded] = useState(depth === 0)
  const isActive = node.path === activeFile
  const statusColor = gitStatus[node.path] ? STATUS_COLORS[gitStatus[node.path]] : undefined

  if (node.type === 'directory') {
    return (
      <div>
        <div
          onClick={() => setExpanded(e => !e)}
          style={{
            display: 'flex', alignItems: 'center', gap: 5,
            padding: `3px 8px 3px ${8 + depth * 14}px`,
            cursor: 'pointer', fontSize: 13,
            color: 'var(--fg2)',
            userSelect: 'none',
          }}
          onMouseEnter={e => (e.currentTarget.style.background = 'var(--bg3)')}
          onMouseLeave={e => (e.currentTarget.style.background = 'none')}
        >
          {expanded
            ? <FolderOpen size={13} color="var(--yellow)" />
            : <Folder size={13} color="var(--yellow)" />}
          <span>{node.name}</span>
        </div>
        {expanded && node.children?.map(child => (
          <TreeNode key={child.path} node={child} depth={depth + 1}
            onOpenFile={onOpenFile} activeFile={activeFile} gitStatus={gitStatus} />
        ))}
      </div>
    )
  }

  return (
    <div
      onClick={() => onOpenFile(node.path)}
      style={{
        display: 'flex', alignItems: 'center', gap: 5,
        padding: `3px 8px 3px ${8 + depth * 14}px`,
        cursor: 'pointer', fontSize: 13,
        background: isActive ? 'color-mix(in srgb, var(--accent) 15%, transparent)' : 'none',
        color: isActive ? 'var(--fg)' : 'var(--fg2)',
        borderLeft: isActive ? '2px solid var(--accent)' : '2px solid transparent',
      }}
      onMouseEnter={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = 'var(--bg3)' }}
      onMouseLeave={e => { if (!isActive) (e.currentTarget as HTMLElement).style.background = 'none' }}
    >
      <FileText size={12} color="var(--fg3)" />
      <span style={{ flex: 1 }}>{node.name}</span>
      {statusColor && (
        <div style={{ width: 7, height: 7, borderRadius: '50%', background: statusColor, flexShrink: 0 }} />
      )}
    </div>
  )
}

export default function FileTree({ onOpenFile, activeFile }: Props) {
  const [tree, setTree] = useState<FileNode | null>(null)
  const [gitStatus, setGitStatus] = useState<GitStatus>({ branch: 'unknown', status: {} })
  const [loading, setLoading] = useState(true)

  const refresh = async () => {
    setLoading(true)
    try {
      const [treeData, gs] = await Promise.all([fetchTree(), fetchGitStatus()])
      setTree(treeData.tree)
      setGitStatus(gs)
    } catch {
      /* ignore */
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { refresh() }, [])

  return (
    <div style={{
      height: '100%', display: 'flex', flexDirection: 'column',
      background: 'var(--bg2)',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '8px 10px',
        borderBottom: '1px solid var(--border)',
        flexShrink: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5, color: 'var(--fg3)', fontSize: 11,
          fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
          <GitBranch size={11} />
          {gitStatus.branch}
        </div>
        <button onClick={refresh} title="Refresh"
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fg3)', padding: 3 }}>
          <RefreshCw size={12} style={{ animation: loading ? 'spin 0.8s linear infinite' : undefined }} />
        </button>
      </div>

      {/* Tree */}
      <div style={{ flex: 1, overflowY: 'auto', paddingBottom: 8 }}>
        {tree && (
          <TreeNode node={tree} depth={0} onOpenFile={onOpenFile}
            activeFile={activeFile} gitStatus={gitStatus.status} />
        )}
        {!tree && !loading && (
          <div style={{ padding: 12, color: 'var(--fg3)', fontSize: 12 }}>
            Empty workspace
          </div>
        )}
      </div>
    </div>
  )
}
