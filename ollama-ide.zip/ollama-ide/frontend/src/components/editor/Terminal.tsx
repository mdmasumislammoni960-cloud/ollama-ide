import { useState, useEffect, useRef, useCallback } from 'react'
import { X, Terminal as TermIcon, Trash2 } from 'lucide-react'

interface Props {
  onClose: () => void
  runPath?: string | null
}

interface Line {
  id: number
  text: string
  type: 'output' | 'error' | 'info' | 'done'
}

let lineId = 0

export default function Terminal({ onClose, runPath }: Props) {
  const [lines, setLines] = useState<Line[]>([])
  const [connected, setConnected] = useState(false)
  const [running, setRunning] = useState(false)
  const wsRef = useRef<WebSocket | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)

  const addLine = useCallback((text: string, type: Line['type'] = 'output') => {
    setLines(prev => [...prev, { id: lineId++, text, type }])
  }, [])

  useEffect(() => {
    const ws = new WebSocket(`ws://localhost:8000/ws/terminal`)
    wsRef.current = ws

    ws.onopen = () => {
      setConnected(true)
      addLine('Terminal connected.', 'info')
    }
    ws.onclose = () => {
      setConnected(false)
      addLine('Terminal disconnected.', 'info')
    }
    ws.onerror = () => addLine('WebSocket error.', 'error')
    ws.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data)
        if (msg.type === 'output') {
          addLine(msg.data, 'output')
        } else if (msg.type === 'error') {
          addLine(msg.data, 'error')
        } else if (msg.type === 'done') {
          setRunning(false)
          addLine(`\nProcess exited with code ${msg.code}`, msg.code === 0 ? 'info' : 'error')
        }
      } catch { /* ignore */ }
    }

    return () => ws.close()
  }, [])

  // Auto-scroll
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'auto' })
  }, [lines])

  // Run file when runPath changes
  useEffect(() => {
    if (!runPath || !connected || running) return
    setRunning(true)
    addLine(`\n$ run ${runPath}`, 'info')
    wsRef.current?.send(JSON.stringify({ type: 'run', path: runPath }))
  }, [runPath])

  const colorMap: Record<Line['type'], string> = {
    output: 'var(--fg)',
    error: 'var(--red)',
    info: 'var(--fg3)',
    done: 'var(--green)',
  }

  return (
    <div style={{
      height: '100%', display: 'flex', flexDirection: 'column',
      background: 'var(--bg)', borderTop: '1px solid var(--border)',
    }}>
      {/* Header */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '4px 10px', background: 'var(--bg2)',
        borderBottom: '1px solid var(--border)', flexShrink: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--fg2)' }}>
          <TermIcon size={12} />
          <span>Terminal</span>
          <div style={{
            width: 6, height: 6, borderRadius: '50%',
            background: connected ? 'var(--green)' : 'var(--red)',
          }} />
          {running && <span style={{ color: 'var(--yellow)', fontSize: 11 }}>running…</span>}
        </div>
        <div style={{ display: 'flex', gap: 4 }}>
          <button onClick={() => setLines([])} title="Clear"
            style={iconBtn}>
            <Trash2 size={12} />
          </button>
          <button onClick={onClose} title="Close terminal"
            style={iconBtn}>
            <X size={12} />
          </button>
        </div>
      </div>

      {/* Output */}
      <div style={{
        flex: 1, overflowY: 'auto', padding: '8px 12px',
        fontFamily: "'JetBrains Mono', monospace", fontSize: 12.5, lineHeight: 1.6,
      }}>
        {lines.map(line => (
          <div key={line.id} style={{ color: colorMap[line.type], whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>
            {line.text}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
    </div>
  )
}

const iconBtn: React.CSSProperties = {
  background: 'none', border: 'none', cursor: 'pointer',
  color: 'var(--fg3)', padding: 3, display: 'flex', alignItems: 'center',
  borderRadius: 3,
}
