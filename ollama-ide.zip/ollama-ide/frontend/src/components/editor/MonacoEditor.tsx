import { Suspense, lazy, useRef } from 'react'
import type { Tab } from '@/types'

const MonacoEditorLib = lazy(() => import('@monaco-editor/react'))

interface Props {
  tab: Tab | null
  theme: string
  onChange: (value: string) => void
  onSave: () => void
}

function EditorSkeleton() {
  return (
    <div style={{
      flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg)', color: 'var(--fg3)', fontSize: 13,
      flexDirection: 'column', gap: 10,
    }}>
      <div style={{ width: 32, height: 32, border: '2px solid var(--accent)', borderTopColor: 'transparent',
        borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
      <span>Loading editor…</span>
    </div>
  )
}

function EmptyState() {
  return (
    <div style={{
      flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'var(--bg)', flexDirection: 'column', gap: 10, color: 'var(--fg3)',
    }}>
      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
        <polyline points="14 2 14 8 20 8"/>
      </svg>
      <span style={{ fontSize: 14 }}>Open a file to start editing</span>
      <span style={{ fontSize: 12 }}>Click a file in the tree →</span>
    </div>
  )
}

export default function MonacoEditor({ tab, theme, onChange, onSave }: Props) {
  const editorRef = useRef<unknown>(null)

  if (!tab) return <EmptyState />

  return (
    <Suspense fallback={<EditorSkeleton />}>
      <MonacoEditorLib
        height="100%"
        language={tab.language}
        value={tab.content}
        theme={theme === 'dark' ? 'vs-dark' : 'vs-light'}
        onChange={v => onChange(v ?? '')}
        onMount={(editor, monaco) => {
          editorRef.current = editor
          // Ctrl+S to save
          editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, onSave)
          editor.updateOptions({
            fontSize: 13,
            fontFamily: "'JetBrains Mono', monospace",
            fontLigatures: true,
            minimap: { enabled: false },
            scrollBeyondLastLine: false,
            renderLineHighlight: 'line',
            lineNumbers: 'on',
            padding: { top: 12, bottom: 12 },
            tabSize: 2,
            wordWrap: 'off',
            cursorBlinking: 'phase',
            smoothScrolling: true,
            contextmenu: true,
          })
        }}
        options={{
          automaticLayout: true,
        }}
      />
    </Suspense>
  )
}
