import type { Tab } from '@/types'
import { X } from 'lucide-react'

interface Props {
  tabs: Tab[]
  activeTab: string | null
  onActivate: (path: string) => void
  onClose: (path: string) => void
}

export default function TabBar({ tabs, activeTab, onActivate, onClose }: Props) {
  if (tabs.length === 0) return null

  return (
    <div style={{
      display: 'flex', alignItems: 'center',
      background: 'var(--bg2)',
      borderBottom: '1px solid var(--border)',
      overflowX: 'auto', flexShrink: 0,
      height: 36,
    }}>
      {tabs.map(tab => {
        const isActive = tab.path === activeTab
        return (
          <div
            key={tab.path}
            onClick={() => onActivate(tab.path)}
            title={tab.path}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '0 10px 0 14px', height: '100%',
              borderRight: '1px solid var(--border)',
              cursor: 'pointer', userSelect: 'none',
              background: isActive ? 'var(--bg)' : 'transparent',
              borderBottom: isActive ? '2px solid var(--accent)' : '2px solid transparent',
              color: isActive ? 'var(--fg)' : 'var(--fg2)',
              fontSize: 12.5, flexShrink: 0,
              transition: 'background 0.1s',
            }}
          >
            <span style={{ maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {tab.name}
            </span>
            {tab.dirty && (
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--yellow)', flexShrink: 0 }} />
            )}
            <button
              onClick={e => { e.stopPropagation(); onClose(tab.path) }}
              style={{
                width: 16, height: 16, borderRadius: 3,
                background: 'none', border: 'none', cursor: 'pointer',
                color: 'var(--fg3)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0,
              }}
              onMouseEnter={e => (e.currentTarget.style.background = 'var(--bg3)')}
              onMouseLeave={e => (e.currentTarget.style.background = 'none')}
            >
              <X size={10} />
            </button>
          </div>
        )
      })}
    </div>
  )
}
