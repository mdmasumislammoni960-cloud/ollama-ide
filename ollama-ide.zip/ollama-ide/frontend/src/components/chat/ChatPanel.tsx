import { useState, useRef, useCallback, useEffect } from 'react'
import type { ModelControls } from '@/types'
import { useChat } from '@/hooks/useChat'
import { useSession } from '@/context/SessionContext'
import { useSettings } from '@/context/SettingsContext'
import MessageList from './MessageList'
import SystemPromptEditor from './SystemPromptEditor'
import ModelControlsPanel from './ModelControls'
import { Send, Square, Plus, Download, PanelRight } from 'lucide-react'

const DEFAULT_CONTROLS: ModelControls = {
  provider: 'ollama',
  model: 'llama3.2',
  temperature: 0.7,
  top_p: 0.9,
  max_tokens: 2048,
  system: '',
}

interface Props {
  compact?: boolean  // when embedded in IDE panel
}

export default function ChatPanel({ compact = false }: Props) {
  const { provider } = useSettings()
  const [controls, setControls] = useState<ModelControls>({
    ...DEFAULT_CONTROLS,
    provider,
  })
  const [input, setInput] = useState('')
  const [showControls, setShowControls] = useState(!compact)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const { messages, streaming } = useSession()
  const { createSession, clearMessages } = useSession()
  const { send, stop } = useChat(controls)

  // Sync provider from settings
  useEffect(() => {
    setControls(c => ({ ...c, provider }))
  }, [provider])

  const handleSend = useCallback(() => {
    if (!input.trim() || streaming) return
    send(input)
    setInput('')
    textareaRef.current?.focus()
  }, [input, streaming, send])

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault()
      handleSend()
    }
  }

  const exportChat = () => {
    const md = messages.map(m => `**${m.role}**\n\n${m.content}`).join('\n\n---\n\n')
    const blob = new Blob([md], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'chat.md'; a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div style={{
      display: 'flex', height: '100%',
      background: 'var(--bg)',
    }}>
      {/* Main chat area */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        {/* System prompt */}
        <SystemPromptEditor
          value={controls.system}
          onChange={v => setControls(c => ({ ...c, system: v }))}
        />

        {/* Toolbar */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '6px 12px',
          borderBottom: '1px solid var(--border)',
          background: 'var(--bg2)',
          flexShrink: 0,
        }}>
          <div style={{ display: 'flex', gap: 6 }}>
            <button onClick={() => { clearMessages(); createSession(controls.provider, controls.model) }}
              title="New session"
              style={btnStyle}>
              <Plus size={13} /> New
            </button>
            <button onClick={exportChat} disabled={messages.length === 0}
              title="Export as Markdown"
              style={{ ...btnStyle, opacity: messages.length === 0 ? 0.4 : 1 }}>
              <Download size={13} /> Export
            </button>
          </div>
          <button onClick={() => setShowControls(s => !s)} title="Toggle model controls"
            style={{ ...btnStyle, color: showControls ? 'var(--accent)' : 'var(--fg2)' }}>
            <PanelRight size={13} />
          </button>
        </div>

        {/* Messages */}
        <MessageList messages={messages} streaming={streaming} />

        {/* Input */}
        <div style={{
          padding: '10px 12px',
          borderTop: '1px solid var(--border)',
          background: 'var(--bg2)',
          flexShrink: 0,
        }}>
          <div style={{
            display: 'flex', gap: 8, alignItems: 'flex-end',
            background: 'var(--bg)',
            border: '1px solid var(--border)',
            borderRadius: 8,
            padding: '8px 10px',
            transition: 'border-color 0.15s',
          }}
            onFocusCapture={e => (e.currentTarget.style.borderColor = 'var(--accent)')}
            onBlurCapture={e => (e.currentTarget.style.borderColor = 'var(--border)')}
          >
            <textarea
              ref={textareaRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Message… (Ctrl+Enter to send)"
              rows={1}
              style={{
                flex: 1, background: 'none', border: 'none', outline: 'none',
                resize: 'none', color: 'var(--fg)', fontSize: 13.5,
                fontFamily: 'inherit', lineHeight: 1.6,
                maxHeight: 160, overflowY: 'auto',
              }}
              onInput={e => {
                const el = e.currentTarget
                el.style.height = 'auto'
                el.style.height = Math.min(el.scrollHeight, 160) + 'px'
              }}
            />
            <button
              onClick={streaming ? stop : handleSend}
              disabled={!streaming && !input.trim()}
              style={{
                width: 32, height: 32, borderRadius: 6, border: 'none',
                cursor: (!streaming && !input.trim()) ? 'not-allowed' : 'pointer',
                background: streaming ? 'var(--red)' : 'var(--accent)',
                color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0, opacity: (!streaming && !input.trim()) ? 0.5 : 1,
                transition: 'all 0.15s',
              }}
            >
              {streaming ? <Square size={13} /> : <Send size={13} />}
            </button>
          </div>
          <div style={{ fontSize: 11, color: 'var(--fg3)', marginTop: 5, textAlign: 'right' }}>
            {controls.provider} · {controls.model}
          </div>
        </div>
      </div>

      {/* Model controls sidebar */}
      {showControls && (
        <ModelControlsPanel controls={controls} onChange={setControls} />
      )}
    </div>
  )
}

const btnStyle: React.CSSProperties = {
  display: 'flex', alignItems: 'center', gap: 4,
  padding: '4px 8px', background: 'none',
  border: '1px solid var(--border)', borderRadius: 'var(--radius)',
  cursor: 'pointer', color: 'var(--fg2)', fontSize: 12,
  transition: 'all 0.15s',
}
