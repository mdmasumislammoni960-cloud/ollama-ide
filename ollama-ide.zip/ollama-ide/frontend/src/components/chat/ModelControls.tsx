import { useEffect } from 'react'
import type { ModelControls as MC, Provider } from '@/types'
import { useProviders } from '@/hooks/useProviders'
import { RefreshCw } from 'lucide-react'

const PROVIDERS: Provider[] = ['ollama', 'anthropic', 'openai', 'google', 'groq']

interface Props {
  controls: MC
  onChange: (c: MC) => void
}

function Slider({ label, value, min, max, step, onChange }: {
  label: string; value: number; min: number; max: number; step: number
  onChange: (v: number) => void
}) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 12, color: 'var(--fg2)' }}>{label}</span>
        <span style={{ fontSize: 12, color: 'var(--accent)', fontFamily: 'var(--font-mono)' }}>
          {value}
        </span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value}
        onChange={e => onChange(parseFloat(e.target.value))}
        style={{ width: '100%', accentColor: 'var(--accent)', cursor: 'pointer' }}
      />
    </div>
  )
}

export default function ModelControls({ controls, onChange }: Props) {
  const { models, loading, refresh } = useProviders(controls.provider)

  useEffect(() => {
    if (models.length > 0 && !models.includes(controls.model)) {
      onChange({ ...controls, model: models[0] })
    }
  }, [models])

  const set = (k: keyof MC, v: string | number) => onChange({ ...controls, [k]: v })

  const selectStyle: React.CSSProperties = {
    width: '100%', padding: '6px 8px',
    background: 'var(--bg)', border: '1px solid var(--border)',
    borderRadius: 'var(--radius)', color: 'var(--fg)', fontSize: 13,
    cursor: 'pointer', outline: 'none',
  }

  return (
    <div style={{
      width: 220, flexShrink: 0, padding: '12px 14px',
      background: 'var(--bg2)', borderLeft: '1px solid var(--border)',
      display: 'flex', flexDirection: 'column', gap: 14,
      overflowY: 'auto',
    }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--fg3)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
        Model
      </div>

      {/* Provider */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <span style={{ fontSize: 12, color: 'var(--fg2)' }}>Provider</span>
        <select style={selectStyle} value={controls.provider}
          onChange={e => set('provider', e.target.value as Provider)}>
          {PROVIDERS.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
      </div>

      {/* Model */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontSize: 12, color: 'var(--fg2)' }}>Model</span>
          <button onClick={refresh} title="Refresh models"
            style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fg3)', padding: 2 }}>
            <RefreshCw size={12} style={{ animation: loading ? 'spin 1s linear infinite' : undefined }} />
          </button>
        </div>
        {models.length > 0 ? (
          <select style={selectStyle} value={controls.model}
            onChange={e => set('model', e.target.value)}>
            {models.map(m => <option key={m} value={m}>{m}</option>)}
          </select>
        ) : (
          <input style={{ ...selectStyle }} value={controls.model}
            onChange={e => set('model', e.target.value)}
            placeholder="Enter model name" />
        )}
      </div>

      <div style={{ height: 1, background: 'var(--border)' }} />
      <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--fg3)', letterSpacing: '0.08em', textTransform: 'uppercase' }}>
        Parameters
      </div>

      <Slider label="Temperature" value={controls.temperature} min={0} max={2} step={0.05}
        onChange={v => set('temperature', v)} />
      <Slider label="Top-P" value={controls.top_p} min={0} max={1} step={0.05}
        onChange={v => set('top_p', v)} />

      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <span style={{ fontSize: 12, color: 'var(--fg2)' }}>Max Tokens</span>
        <input type="number" min={1} max={32768} value={controls.max_tokens}
          onChange={e => set('max_tokens', parseInt(e.target.value) || 2048)}
          style={{ ...selectStyle, fontFamily: "'JetBrains Mono', monospace" }} />
      </div>
    </div>
  )
}
