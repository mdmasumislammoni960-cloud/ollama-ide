import { useEffect, useRef } from 'react'
import type { Message } from '@/types'
import { User, Bot, Copy, Check } from 'lucide-react'
import { useState } from 'react'

function CodeBlock({ code, lang }: { code: string; lang?: string }) {
  const [copied, setCopied] = useState(false)
  const copy = () => {
    navigator.clipboard.writeText(code)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <div style={{ position: 'relative', margin: '8px 0' }}>
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '4px 10px', background: 'var(--bg3)',
        borderRadius: 'var(--radius) var(--radius) 0 0',
        borderBottom: '1px solid var(--border)',
      }}>
        <span style={{ fontSize: 11, color: 'var(--fg3)', fontFamily: "'JetBrains Mono', monospace" }}>
          {lang ?? 'code'}
        </span>
        <button onClick={copy} style={{
          background: 'none', border: 'none', cursor: 'pointer',
          color: copied ? 'var(--green)' : 'var(--fg3)', display: 'flex', alignItems: 'center', gap: 4,
          fontSize: 11,
        }}>
          {copied ? <Check size={12} /> : <Copy size={12} />}
          {copied ? 'copied' : 'copy'}
        </button>
      </div>
      <pre style={{
        margin: 0, padding: '12px 14px',
        background: 'var(--bg)', border: '1px solid var(--border)',
        borderTop: 'none', borderRadius: '0 0 var(--radius) var(--radius)',
        overflowX: 'auto', fontSize: 12.5,
        fontFamily: "'JetBrains Mono', monospace", lineHeight: 1.6,
      }}>
        <code>{code}</code>
      </pre>
    </div>
  )
}

function renderContent(content: string, streaming: boolean) {
  // Simple markdown-ish renderer
  const blocks: React.ReactNode[] = []
  const codeBlockRx = /```(\w*)\n([\s\S]*?)```/g
  let last = 0, match: RegExpExecArray | null, i = 0

  while ((match = codeBlockRx.exec(content)) !== null) {
    if (match.index > last) {
      blocks.push(
        <span key={i++} style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
          {content.slice(last, match.index)}
        </span>
      )
    }
    blocks.push(<CodeBlock key={i++} lang={match[1] || undefined} code={match[2]} />)
    last = match.index + match[0].length
  }

  const tail = content.slice(last)
  if (tail) {
    blocks.push(
      <span key={i++}
        className={streaming ? 'cursor-blink' : undefined}
        style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
        {tail}
      </span>
    )
  } else if (streaming) {
    blocks.push(<span key="cursor" className="cursor-blink" />)
  }

  return blocks
}

interface Props {
  messages: Message[]
  streaming: boolean
}

export default function MessageList({ messages, streaming }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, streaming])

  if (messages.length === 0) {
    return (
      <div style={{
        flex: 1, display: 'flex', flexDirection: 'column',
        alignItems: 'center', justifyContent: 'center', gap: 10,
        color: 'var(--fg3)',
      }}>
        <Bot size={36} strokeWidth={1.2} />
        <p style={{ fontSize: 14 }}>Start a conversation</p>
      </div>
    )
  }

  return (
    <div style={{ flex: 1, overflowY: 'auto', padding: '16px 0' }}>
      {messages.map((msg, idx) => {
        const isUser = msg.role === 'user'
        const isLast = idx === messages.length - 1
        const isStreaming = streaming && isLast && !isUser

        return (
          <div key={msg.id}
            className="fade-in"
            style={{
              display: 'flex', gap: 10,
              padding: '8px 16px',
              background: isUser ? 'transparent' : 'color-mix(in srgb, var(--accent) 4%, transparent)',
              borderBottom: '1px solid color-mix(in srgb, var(--border) 50%, transparent)',
            }}>
            {/* Avatar */}
            <div style={{
              width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: isUser
                ? 'color-mix(in srgb, var(--blue) 20%, transparent)'
                : 'color-mix(in srgb, var(--accent) 20%, transparent)',
              color: isUser ? 'var(--blue)' : 'var(--accent)',
              marginTop: 2,
            }}>
              {isUser ? <User size={13} /> : <Bot size={13} />}
            </div>

            {/* Content */}
            <div style={{ flex: 1, minWidth: 0, lineHeight: 1.65, fontSize: 13.5 }}>
              <div style={{
                fontSize: 11, color: 'var(--fg3)', marginBottom: 4,
                fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase',
              }}>
                {isUser ? 'You' : 'Assistant'}
              </div>
              <div className="prose-chat">
                {renderContent(msg.content, isStreaming)}
              </div>
            </div>
          </div>
        )
      })}
      <div ref={bottomRef} />
    </div>
  )
}
