import { useState } from 'react'
import { ChevronDown, ChevronRight } from 'lucide-react'

interface Props {
  value: string
  onChange: (v: string) => void
}

export default function SystemPromptEditor({ value, onChange }: Props) {
  const [open, setOpen] = useState(false)

  return (
    <div style={{
      background: 'var(--bg2)',
      borderBottom: '1px solid var(--border)',
      flexShrink: 0,
    }}>
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 6,
          padding: '8px 14px', background: 'none', border: 'none',
          cursor: 'pointer', color: 'var(--fg2)', fontSize: 12,
          textAlign: 'left',
        }}
      >
        {open ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
        <span style={{ fontWeight: 500 }}>System Prompt</span>
        {value && !open && (
          <span style={{
            flex: 1, overflow: 'hidden', textOverflow: 'ellipsis',
            whiteSpace: 'nowrap', color: 'var(--fg3)', fontSize: 11,
          }}>
            {value}
          </span>
        )}
        {value && (
          <span style={{
            fontSize: 10, padding: '2px 6px',
            background: 'color-mix(in srgb, var(--accent) 15%, transparent)',
            color: 'var(--accent)', borderRadius: 4,
          }}>set</span>
        )}
      </button>
      {open && (
        <div style={{ padding: '0 14px 12px' }}>
          <textarea
            value={value}
            onChange={e => onChange(e.target.value)}
            placeholder="You are a helpful assistant..."
            rows={4}
            style={{
              width: '100%', padding: '8px 10px',
              background: 'var(--bg)', border: '1px solid var(--border)',
              borderRadius: 'var(--radius)', color: 'var(--fg)',
              fontSize: 13, fontFamily: "'JetBrains Mono', monospace",
              resize: 'vertical', outline: 'none', lineHeight: 1.6,
            }}
          />
        </div>
      )}
    </div>
  )
}
