# Ollama IDE

A full-stack AI-powered IDE and Playground supporting local Ollama models and cloud providers (Anthropic, OpenAI, Google Gemini, Groq) through a unified interface.

## Stack

| Layer     | Technology                                      |
|-----------|-------------------------------------------------|
| Frontend  | React 18 + Vite + TypeScript + TailwindCSS      |
| Editor    | Monaco Editor (lazy-loaded)                     |
| Panels    | react-resizable-panels                          |
| Backend   | Python 3.11 + FastAPI + uvicorn                 |
| Streaming | SSE for chat · WebSocket for terminal           |
| Storage   | SQLite (sessions) · `.env` (API keys)           |

---

## Quick Start

### 1. Clone & enter the project

```bash
git clone <repo-url> ollama-ide
cd ollama-ide
```

### 2. Configure environment

```bash
cp .env.example backend/.env
# Edit backend/.env and add your API keys (all optional except Ollama)
```

### 3. Install everything

```bash
make setup
# or manually:
cd frontend && npm install
cd backend && pip install -r requirements.txt
```

### 4. Run

```bash
make dev
```

- Frontend: http://localhost:5173  
- Backend API: http://localhost:8000  
- API docs: http://localhost:8000/docs

---

## Pages

### `/playground` — Chat Playground
- Full-height streaming chat interface
- Collapsible system prompt editor
- Model controls sidebar (provider, model, temperature, top-p, max tokens)
- Session history with auto-generated titles
- Export chat as Markdown
- `Ctrl+Enter` to send

### `/ide` — Code Editor
- Three-panel layout: File Tree · Monaco Editor · AI Chat
- Git status dots in file tree (🟡 modified · 🟢 untracked · 🔵 staged)
- Multi-tab editor with unsaved indicator
- Integrated terminal (WebSocket, live subprocess output)
- Run button executes the current file
- `Ctrl+S` to save

### `/settings` — Configuration
- Ollama connection URL + live health check
- API key inputs per provider (masked, stored in memory only — never returned)
- Workspace root folder path
- Dark / Light theme toggle

---

## Provider Setup

### Ollama (local, no key needed)
```bash
# Install: https://ollama.com
ollama pull llama3.2
ollama serve  # starts on localhost:11434
```

### Cloud providers
Enter API keys in `/settings` or add them to `backend/.env`:
```env
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
GOOGLE_API_KEY=AIza...
GROQ_API_KEY=gsk_...
```

---

## Project Structure

```
ollama-ide/
├── Makefile
├── .env.example
├── frontend/
│   └── src/
│       ├── api/          # fetch + SSE clients
│       ├── components/
│       │   ├── chat/     # ChatPanel, MessageList, ModelControls, SystemPromptEditor
│       │   ├── editor/   # MonacoEditor, FileTree, TabBar, Terminal
│       │   └── ui/       # Navbar, OllamaStatus, ThemeToggle
│       ├── context/      # SessionContext, SettingsContext
│       ├── hooks/        # useChat, useEditor, useProviders
│       ├── pages/        # PlaygroundPage, IdePage, SettingsPage
│       └── types/
└── backend/
    ├── main.py           # FastAPI entry + CORS + WebSocket
    └── app/
        ├── core/         # config, security (path jail)
        ├── providers/    # ollama, anthropic, openai, google, groq + factory
        ├── routers/      # chat (SSE), files, settings
        ├── services/     # executor, git_service, session_store
        └── models/       # Pydantic schemas
```

---

## Security

- **Path jail** — all file operations are sandboxed to `WORKSPACE_ROOT` via `safe_path()`. Path traversal returns HTTP 403.
- **API keys** — stored in process env only. The settings GET endpoint returns booleans only, never key values.
- **Subprocess timeout** — `MAX_EXEC_TIMEOUT` (default 10s) hard-kills runaway processes.
- **CORS** — restricted to `localhost:5173` in development.
- **No key logging** — API keys never appear in logs or error responses.

---

## Streaming Architecture

```
Chat request  →  POST /api/chat/stream  →  SSE (text/event-stream)
                 fetch + ReadableStream on the frontend

Terminal run  →  WebSocket /ws/terminal  →  bidirectional
                 live stdout chunks streamed back as JSON messages
```

---

## Development Commands

```bash
make dev        # start both servers (frontend + backend)
make backend    # backend only  (port 8000)
make frontend   # frontend only (port 5173)
make build      # production build of frontend
make install    # install all dependencies
```

---

## Environment Variables

| Variable            | Default                    | Description                        |
|---------------------|----------------------------|------------------------------------|
| `OLLAMA_BASE_URL`   | `http://localhost:11434`   | Ollama server URL                  |
| `ANTHROPIC_API_KEY` | _(empty)_                  | Anthropic Claude API key           |
| `OPENAI_API_KEY`    | _(empty)_                  | OpenAI API key                     |
| `GOOGLE_API_KEY`    | _(empty)_                  | Google Gemini API key              |
| `GROQ_API_KEY`      | _(empty)_                  | Groq API key                       |
| `WORKSPACE_ROOT`    | `./workspace`              | Root folder for file tree & runner |
| `MAX_EXEC_TIMEOUT`  | `10`                       | Max subprocess runtime (seconds)   |
